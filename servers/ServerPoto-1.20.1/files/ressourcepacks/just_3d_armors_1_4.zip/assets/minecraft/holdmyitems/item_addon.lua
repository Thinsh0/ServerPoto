global.pitchAngle = 0.0;
global.yawAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngleO = 0.0;
global.offHand = 0.0; 
global.wasOnGround = wasOnGround or true;


local ywAngle = (context.mainHand and yawAngle) or yawAngleO
local ptAngle = (context.mainHand and pitchAngle) or pitchAngleO

local l = data.bl and 1 or -1


local item = context.item
local matrices = context.matrices
local player = context.player
local particles = context.particles

if I:isOf(item, Items:get("minecraft:copper_chestplate")) or I:isOf(item, Items:get("minecraft:diamond_leggings")) or I:isOf(item, Items:get("minecraft:copper_leggings")) or I:isOf(item, Items:get("minecraft:elytra")) or I:isOf(item, Items:get("minecraft:chainmail_chestplate")) or I:isOf(item, Items:get("minecraft:iron_chestplate")) or I:isOf(item, Items:get("minecraft:diamond_chestplate")) or I:isOf(item, Items:get("minecraft:netherite_chestplate")) or I:isOf(item, Items:get("minecraft:golden_chestplate")) or I:isOf(item, Items:get("minecraft:golden_leggings")) or I:isOf(item, Items:get("minecraft:iron_leggings")) or I:isOf(item, Items:get("minecraft:chainmail_leggings")) or I:isOf(item, Items:get("minecraft:leather_leggings")) or I:isOf(item, Items:get("minecraft:netherite_leggings")) then
    M:moveY(matrices, -0.07)
    M:moveZ(matrices, 0)
    M:rotateX(matrices, -39)
    M:rotateX(matrices, M:clamp(P:getPitch(player) / 2.5, -15, 80) + ptAngle + ywAngle * 0.3, 0, -0.13, 0)
end

if I:isOf(item, Items:get("minecraft:copper_boots")) or I:isOf(item, Items:get("minecraft:golden_boots")) or I:isOf(item, Items:get("minecraft:chainmail_boots")) or I:isOf(item, Items:get("minecraft:iron_boots")) or I:isOf(item, Items:get("minecraft:diamond_boots")) or I:isOf(item, Items:get("minecraft:netherite_boots")) then
    M:moveY(matrices, -0.15)
    M:moveZ(matrices, 0.0)
    M:rotateX(matrices, -39)
    M:rotateX(matrices, M:clamp(P:getPitch(player) / 2.5, -15, 80) + ptAngle + ywAngle * 0.3, 0, -0.13, 0)
end


local onGround = P:isOnGround(context.player)

if (
    I:isOf(context.item, Items:get("minecraft:diamond_horse_armor")) or
    I:isOf(context.item, Items:get("minecraft:netherite_horse_armor")) or
    I:isOf(context.item, Items:get("minecraft:golden_horse_armor")) or
    I:isOf(context.item, Items:get("minecraft:copper_horse_armor")) or
    I:isOf(context.item, Items:get("minecraft:iron_horse_armor")) or
	I:isOf(context.item, Items:get("minecraft:diamond_chestplate")) or
	I:isOf(context.item, Items:get("minecraft:copper_chestplate")) or
	I:isOf(context.item, Items:get("minecraft:iron_chestplate")) or
	I:isOf(context.item, Items:get("minecraft:chainmail_chestplate")) or
	I:isOf(context.item, Items:get("minecraft:netherite_chestplate")) or
	I:isOf(context.item, Items:get("minecraft:golden_chestplate")) or
	I:isOf(context.item, Items:get("minecraft:diamond_leggings")) or
	I:isOf(context.item, Items:get("minecraft:golden_leggings")) or
	I:isOf(context.item, Items:get("minecraft:iron_leggings")) or
	I:isOf(context.item, Items:get("minecraft:copper_leggings")) or
	I:isOf(context.item, Items:get("minecraft:chainmail_leggings")) or
	I:isOf(context.item, Items:get("minecraft:netherite_leggings")) or
	I:isOf(context.item, Items:get("minecraft:diamond_boots")) or
	I:isOf(context.item, Items:get("minecraft:copper_boots")) or
	I:isOf(context.item, Items:get("minecraft:golden_boots")) or
	I:isOf(context.item, Items:get("minecraft:iron_boots")) or
	I:isOf(context.item, Items:get("minecraft:chainmail_boots")) or
	I:isOf(context.item, Items:get("minecraft:netherite_boots"))  
)
and wasOnGround
and not onGround
then
    S:playSound("custom.metal", 2)
	
elseif (
    I:isOf(context.item, Items:get("minecraft:leather_leggings")) or 
	I:isOf(context.item, Items:get("minecraft:leather_horse_armor"))
)	
and wasOnGround
and not onGround
then
    S:playSound("custom.leather", 2)	

elseif (
    I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:diamond_horse_armor")) or
    I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:netherite_horse_armor")) or
    I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:golden_horse_armor")) or
    I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:copper_horse_armor")) or
    I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:iron_horse_armor")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:diamond_chestplate")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:copper_chestplate")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:iron_chestplate")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:chainmail_chestplate")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:golden_chestplate")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:netherite_chestplate")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:diamond_leggings")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:copper_leggings")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:golden_leggings")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:iron_leggings")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:chainmail_leggings")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:netherite_leggings")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:diamond_boots")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:copper_boots")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:golden_boots")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:iron_boots")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:chainmail_boots")) or
	I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:netherite_boots"))
)
and wasOnGround
and not onGround
then
    S:playSound("custom.metal", 2)
	
elseif ( 
    I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:leather_leggings")) or 
    I:isOf(P:getOffhandItem(context.player), Items:get("minecraft:leather_horse_armor"))
)
and wasOnGround
and not onGround
then
    S:playSound("custom.leather", 2)
end

wasOnGround = onGround