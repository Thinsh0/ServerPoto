global.pitchAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngle = 0.0;
global.yawAngleO = 0.0;

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

local item = context.item
local matrices = context.matrices
local player = context.player
local particles = context.particles

if I:isOf(item, Items:get("minecraft:copper_leggings")) or I:isOf(item, Items:get("minecraft:copper_chestplate")) or I:isOf(item, Items:get("minecraft:chainmail_chestplate")) or I:isOf(item, Items:get("minecraft:iron_chestplate")) or I:isOf(item, Items:get("minecraft:diamond_chestplate")) or I:isOf(item, Items:get("minecraft:netherite_chestplate")) or I:isOf(item, Items:get("minecraft:golden_chestplate")) or I:isOf(item, Items:get("minecraft:golden_leggings")) or I:isOf(item, Items:get("minecraft:iron_leggings")) or I:isOf(item, Items:get("minecraft:chainmail_leggings")) or I:isOf(item, Items:get("minecraft:diamond_leggings")) or I:isOf(item, Items:get("minecraft:leather_leggings")) or I:isOf(item, Items:get("minecraft:netherite_leggings")) then
    M:moveY(matrices, 0.4)
    M:moveZ(matrices, -0.05)
end

if I:isOf(item, Items:get("minecraft:copper_boots")) or I:isOf(item, Items:get("minecraft:golden_boots")) or I:isOf(item, Items:get("minecraft:chainmail_boots")) or I:isOf(item, Items:get("minecraft:iron_boots")) or I:isOf(item, Items:get("minecraft:diamond_boots")) or I:isOf(item, Items:get("minecraft:netherite_boots")) then
    M:moveY(matrices, 0.29)
    M:moveZ(matrices, -0.04)
end

if I:isOf(item, Items:get("minecraft:elytra")) then
    M:moveY(matrices, 0.45)
    M:moveZ(matrices, -0.03)
    M:rotateY(matrices, 0.4)
end