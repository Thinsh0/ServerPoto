global.pitchAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngle = 0.0;
global.yawAngleO = 0.0;
global.fall = 0.0;

local ywAngle = data.mainHand and yawAngle or yawAngleO
local ptAngle = data.mainHand and pitchAngle or pitchAngleO

local l = data.bl and 1 or -1

if I:isOf(data.item, Items:get("minecraft:diamond_horse_armor")) or I:isOf(data.item, Items:get("minecraft:netherite_horse_armor")) or I:isOf(data.item, Items:get("minecraft:leather_horse_armor")) or I:isOf(data.item, Items:get("minecraft:golden_horse_armor")) or I:isOf(data.item, Items:get("minecraft:copper_horse_armor")) or I:isOf(data.item, Items:get("minecraft:iron_horse_armor")) then
    local f = M:clamp(fall + 0.3, 0, 1)
  --animator:rotateZ( 10, 25, M:clamp(P:getPitch(data.player) / 2.5, -20, 90) + ptAngle, 0.3, 0.9, 0)
    animator:rotateZ( 10, 25, ptAngle * 0.6, 0.71, 0.23, 0.0)
    animator:rotateZ( 26, 41, ptAngle * -0.6, 0.2, 0.22, 0.0)
    animator:rotateZ( 10, 25, ywAngle * 0.6, 0.71, 0.23, 0.0)
    animator:rotateZ( 26, 41, ywAngle * -0.6, 0.3, 0.22, 0.0)
    animator:rotateZ( 42, 43, ptAngle * 1.5, 0.7, 0, 0.0)
    animator:rotateZ( 44, 45, ptAngle * -1.5, 0.2, 0, 0.0)
    animator:rotateZ( 42, 43, ywAngle * 1.5, 0.7, 0, 0.0)
    animator:rotateZ( 44, 45, ywAngle * -1.5, 0.3, 0, 0.0)

    animator:moveY(46, 64, M:clamp(0.07 * fall, -0.2, 100))
    animator:moveY(65, 120, f * 0.1)
    animator:moveY(0, 120, M:clamp(0.08 * fall, 0, 150))
end

if I:isOf(data.item, Items:get("minecraft:diamond_chestplate")) then
    animator:rotateZ( 106, 148, ptAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 147, 187, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 106, 148, ywAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 147, 187, ywAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateX( 106, 146, ptAngle * -0.2, 0.71, 0.8, 0.05)
	animator:rotateX( 147, 187, ptAngle * -0.2, 0.2, 0.8, 0.05)
	animator:rotateX( 106, 146, ywAngle * -0.1, 0.71, 0.8, 0.05)
	animator:rotateX( 147, 187, ywAngle * -0.1, 0.2, 0.8, 0.05)
--outline
    animator:rotateZ( 310, 351, ptAngle * 0.6, 0.71, 0.8, 0.0)
    animator:rotateZ( 352, 396, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 310, 351, ywAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 352, 396, ywAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateX( 310, 351, ptAngle * -0.2, 0.71, 0.8, 0.05)
	animator:rotateX( 352, 396, ptAngle * -0.2, 0.2, 0.8, 0.05)
	animator:rotateX( 310, 351, ywAngle * -0.1, 0.71, 0.8, 0.05)
	animator:rotateX( 352, 396, ywAngle * -0.1, 0.2, 0.8, 0.05)
	
elseif I:isOf(data.item, Items:get("minecraft:copper_chestplate")) then
    animator:rotateZ( 90, 124, ptAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 125, 159, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 90, 124, ywAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 125, 159, ywAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateX( 90, 124, ptAngle * -0.2, 0.71, 0.8, 0.05)
	animator:rotateX( 125, 159, ptAngle * -0.2, 0.2, 0.8, 0.05)
	animator:rotateX( 90, 124, ywAngle * -0.1, 0.71, 0.8, 0.05)
	animator:rotateX( 125, 159, ywAngle * -0.1, 0.2, 0.8, 0.05)
--outline
    animator:rotateZ( 232, 266, ptAngle * 0.6, 0.71, 0.8, 0.0)
    animator:rotateZ( 267, 301, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 232, 266, ywAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 267, 301, ywAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateX( 232, 266, ptAngle * -0.2, 0.71, 0.8, 0.05)
	animator:rotateX( 267, 301, ptAngle * -0.2, 0.2, 0.8, 0.05)
	animator:rotateX( 232, 266, ywAngle * -0.1, 0.71, 0.8, 0.05)
	animator:rotateX( 267, 301, ywAngle * -0.1, 0.2, 0.8, 0.05)
	
elseif I:isOf(data.item, Items:get("minecraft:netherite_chestplate")) then
    animator:rotateZ( 84, 101, ptAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 102, 119, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 84, 101, ywAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 102, 119, ywAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateX( 84, 101, ptAngle * -0.2, 0.71, 0.8, 0.05)
	animator:rotateX( 102, 119, ptAngle * -0.2, 0.2, 0.8, 0.05)
	animator:rotateX( 84, 101, ywAngle * -0.1, 0.71, 0.8, 0.05)
	animator:rotateX( 102, 119, ywAngle * -0.1, 0.2, 0.8, 0.05)
--outline
    animator:rotateZ( 156, 172, ptAngle * 0.6, 0.71, 0.8, 0.0)
    animator:rotateZ( 173, 191, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 156, 172, ywAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 173, 191, ywAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateX( 156, 172, ptAngle * -0.2, 0.71, 0.8, 0.05)
	animator:rotateX( 173, 191, ptAngle * -0.2, 0.2, 0.8, 0.05)
	animator:rotateX( 156, 172, ywAngle * -0.1, 0.71, 0.8, 0.05)
	animator:rotateX( 173, 191, ywAngle * -0.1, 0.2, 0.8, 0.05)	
	
elseif I:isOf(data.item, Items:get("minecraft:iron_chestplate")) then
    animator:rotateZ( 78, 89, ptAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 90, 101, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 78, 89, ywAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 90, 101, ywAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateX( 78, 89, ptAngle * -0.2, 0.71, 0.8, 0.05)
	animator:rotateX( 90, 101, ptAngle * -0.2, 0.2, 0.8, 0.05)
	animator:rotateX( 78, 89, ywAngle * -0.1, 0.71, 0.8, 0.05)
	animator:rotateX( 90, 101, ywAngle * -0.1, 0.2, 0.8, 0.05)
--outline
    animator:rotateZ( 180, 191, ptAngle * 0.6, 0.71, 0.8, 0.0)
    animator:rotateZ( 192, 203, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 180, 191, ywAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 192, 203, ywAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateX( 180, 191, ptAngle * -0.2, 0.71, 0.8, 0.05)
	animator:rotateX( 192, 203, ptAngle * -0.2, 0.2, 0.8, 0.05)
	animator:rotateX( 180, 191, ywAngle * -0.1, 0.71, 0.8, 0.05)
	animator:rotateX( 192, 203, ywAngle * -0.1, 0.2, 0.8, 0.05)	
	
elseif I:isOf(data.item, Items:get("minecraft:chainmail_chestplate")) then
    animator:rotateZ( 70, 81, ptAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 82, 93, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 70, 81, ywAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 82, 93, ywAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateX( 70, 81, ptAngle * -0.2, 0.71, 0.8, 0.05)
	animator:rotateX( 82, 93, ptAngle * -0.2, 0.2, 0.8, 0.05)
	animator:rotateX( 70, 81, ywAngle * -0.1, 0.71, 0.8, 0.05)
	animator:rotateX( 82, 93, ywAngle * -0.1, 0.2, 0.8, 0.05)
--outline
    animator:rotateZ( 172, 183, ptAngle * 0.6, 0.71, 0.8, 0.0)
    animator:rotateZ( 184, 195, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 172, 183, ywAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 184, 195, ywAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateX( 172, 183, ptAngle * -0.2, 0.71, 0.8, 0.05)
	animator:rotateX( 184, 195, ptAngle * -0.2, 0.2, 0.8, 0.05)
	animator:rotateX( 172, 183, ywAngle * -0.1, 0.71, 0.8, 0.05)
	animator:rotateX( 184, 195, ywAngle * -0.1, 0.2, 0.8, 0.05)	

elseif I:isOf(data.item, Items:get("minecraft:golden_chestplate")) then
    animator:rotateZ( 78, 93, ptAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 94, 110, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 78, 93, ywAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 94, 110, ywAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateX( 78, 93, ptAngle * -0.2, 0.71, 0.8, 0.05)
	animator:rotateX( 94, 110, ptAngle * -0.2, 0.2, 0.8, 0.05)
	animator:rotateX( 78, 93, ywAngle * -0.1, 0.71, 0.8, 0.05)
	animator:rotateX( 94, 110, ywAngle * -0.1, 0.2, 0.8, 0.05)
--outline
    animator:rotateZ( 192, 209, ptAngle * 0.6, 0.71, 0.8, 0.0)
    animator:rotateZ( 210, 228, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 192, 209, ywAngle * 0.6, 0.71, 0.8, 0.0)
	animator:rotateZ( 210, 228, ywAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateX( 192, 209, ptAngle * -0.2, 0.71, 0.8, 0.05)
	animator:rotateX( 210, 228, ptAngle * -0.2, 0.2, 0.8, 0.05)
	animator:rotateX( 192, 209, ywAngle * -0.1, 0.71, 0.8, 0.05)
	animator:rotateX( 210, 228, ywAngle * -0.1, 0.2, 0.8, 0.05)

elseif I:isOf(data.item, Items:get("minecraft:diamond_leggings")) or I:isOf(data.item, Items:get("minecraft:copper_leggings")) or I:isOf(data.item, Items:get("minecraft:golden_leggings")) or I:isOf(data.item, Items:get("minecraft:leather_leggings")) or I:isOf(data.item, Items:get("minecraft:chainmail_leggings")) then
    animator:rotateZ( 30, 35, ptAngle * 0.7, 0.4, 0.85, 0.0)
	animator:rotateZ( 36, 41, ptAngle * -0.7, 0.2, 0.8, 0.0)
	animator:rotateZ( 30, 35, ywAngle * 0.4, 0.4, 0.8, 0.0)
	animator:rotateZ( 36, 41, ywAngle * 0.4, 0.2, 0.8, 0.0)
	--legs
	animator:rotateZ( 0, 11, ywAngle * 0.55, 0.5, 0.7, 0.0)
	animator:rotateZ( 12, 23, ywAngle * 0.45, 0.2, 0.7, 0.0)
	animator:rotateZ( 0, 11, ptAngle * 0.4, 0.5, 0.7, 0.0)
	animator:rotateZ( 12, 23, ptAngle * -0.3, 0.2, 0.7, 0.0)
	animator:rotateX( 0, 11, ptAngle * -0.4, 0.5, 0.7, 0.0)
	animator:rotateX( 12, 23, ptAngle * -0.4, 0.2, 0.7, 0.0)
	--outline
	animator:rotateZ( 78, 84, ptAngle * 0.6, 0.4, 0.85, 0.0)
	animator:rotateZ( 66, 71, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 78, 84, ywAngle * 0.3, 0.4, 0.8, 0.0)
	animator:rotateZ( 66, 71, ywAngle * 0.3, 0.2, 0.8, 0.0)
	--legs
	animator:rotateZ( 42, 53, ywAngle * 0.55, 0.5, 0.7, 0.0)
	animator:rotateZ( 54, 65, ywAngle * 0.45, 0.2, 0.7, 0.0)
	animator:rotateZ( 42, 53, ptAngle * 0.4, 0.5, 0.7, 0.0)
	animator:rotateZ( 54, 65, ptAngle * -0.3, 0.2, 0.7, 0.0)
	animator:rotateX( 42, 53, ptAngle * -0.4, 0.5, 0.7, 0.0)
	animator:rotateX( 54, 65, ptAngle * -0.4, 0.2, 0.7, 0.0)
	
elseif I:isOf(data.item, Items:get("minecraft:netherite_leggings")) then
    animator:rotateZ( 36, 47, ptAngle * 0.7, 0.4, 0.85, 0.0)
	animator:rotateZ( 48, 59, ptAngle * -0.7, 0.2, 0.8, 0.0)
	animator:rotateZ( 36, 47, ywAngle * 0.4, 0.4, 0.8, 0.0)
	animator:rotateZ( 48, 59, ywAngle * 0.4, 0.2, 0.8, 0.0)
	--legs
	animator:rotateZ( 0, 17, ywAngle * 0.55, 0.5, 0.7, 0.0)
	animator:rotateZ( 18, 35, ywAngle * 0.45, 0.2, 0.7, 0.0)
	animator:rotateZ( 0, 17, ptAngle * 0.4, 0.5, 0.7, 0.0)
	animator:rotateZ( 18, 35, ptAngle * -0.3, 0.2, 0.7, 0.0)
	animator:rotateX( 0, 17, ptAngle * -0.4, 0.5, 0.7, 0.0)
	animator:rotateX( 18, 35, ptAngle * -0.4, 0.2, 0.7, 0.0)
	--outline
	animator:rotateZ( 96, 107, ptAngle * 0.6, 0.4, 0.85, 0.0)
	animator:rotateZ( 108, 119, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 96, 107, ywAngle * 0.3, 0.4, 0.8, 0.0)
	animator:rotateZ( 108, 119, ywAngle * 0.3, 0.2, 0.8, 0.0)
	--legs
	animator:rotateZ( 66, 77, ywAngle * 0.55, 0.5, 0.7, 0.0)
	animator:rotateZ( 78, 89, ywAngle * 0.45, 0.2, 0.7, 0.0)
	animator:rotateZ( 66, 77, ptAngle * 0.4, 0.5, 0.7, 0.0)
	animator:rotateZ( 78, 89, ptAngle * -0.3, 0.2, 0.7, 0.0)
	animator:rotateX( 66, 77, ptAngle * -0.4, 0.5, 0.7, 0.0)
	animator:rotateX( 78, 89, ptAngle * -0.4, 0.2, 0.7, 0.0)

elseif I:isOf(data.item, Items:get("minecraft:iron_leggings")) then
    animator:rotateZ( 37, 43, ptAngle * 0.7, 0.4, 0.85, 0.0)
	animator:rotateZ( 44, 49, ptAngle * -0.7, 0.2, 0.8, 0.0)
	animator:rotateZ( 37, 43, ywAngle * 0.4, 0.4, 0.8, 0.0)
	animator:rotateZ( 44, 49, ywAngle * 0.4, 0.2, 0.8, 0.0)
	--legs
	animator:rotateZ( 0, 15, ywAngle * 0.55, 0.5, 0.7, 0.0)
	animator:rotateZ( 16, 31, ywAngle * 0.45, 0.2, 0.7, 0.0)
	animator:rotateZ( 0, 15, ptAngle * 0.4, 0.5, 0.7, 0.0)
	animator:rotateZ( 16, 31, ptAngle * -0.3, 0.2, 0.7, 0.0)
	animator:rotateX( 0, 15, ptAngle * -0.4, 0.5, 0.7, 0.0)
	animator:rotateX( 16, 31, ptAngle * -0.4, 0.2, 0.7, 0.0)
	--outline
	animator:rotateZ( 80, 84, ptAngle * 0.6, 0.4, 0.85, 0.0)
	animator:rotateZ( 85, 92, ptAngle * -0.6, 0.2, 0.8, 0.0)
	animator:rotateZ( 80, 84, ywAngle * 0.3, 0.4, 0.8, 0.0)
	animator:rotateZ( 85, 92, ywAngle * 0.3, 0.2, 0.8, 0.0)
	--legs
	animator:rotateZ( 50, 61, ywAngle * 0.55, 0.5, 0.7, 0.0)
	animator:rotateZ( 62, 73, ywAngle * 0.45, 0.2, 0.7, 0.0)
	animator:rotateZ( 50, 61, ptAngle * 0.4, 0.5, 0.7, 0.0)
	animator:rotateZ( 62, 73, ptAngle * -0.3, 0.2, 0.7, 0.0)
	animator:rotateX( 50, 61, ptAngle * -0.4, 0.5, 0.7, 0.0)
	animator:rotateX( 62, 73, ptAngle * -0.4, 0.2, 0.7, 0.0)	
	
elseif I:isOf(data.item, Items:get("minecraft:diamond_boots")) or I:isOf(data.item, Items:get("minecraft:copper_boots")) then
    animator:rotateZ( 0, 35, ywAngle * 0.4, 0.4, 0.6, 0.1)
	animator:rotateZ( 36, 71, ywAngle * 0.4, 0.37, 0.6, 0.1)
	animator:rotateZ( 0, 35, ptAngle * 0.3, 0.4, 0.6, 0.1)
	animator:rotateZ( 36, 71, ptAngle * -0.3, 0.37, 0.6, 0.1)
	animator:rotateX( 0, 35, ptAngle * -0.4, 0.4, 0.6, 0.1)
	animator:rotateX( 36, 71, ptAngle * -0.4, 0.37, 0.6, 0.1)
	--outline
	animator:rotateZ( 72, 107, ywAngle * 0.4, 0.4, 0.6, 0.1)
	animator:rotateZ( 108, 143, ywAngle * 0.4, 0.37, 0.6, 0.1)
	animator:rotateZ( 72, 107, ptAngle * 0.3, 0.4, 0.6, 0.1)
	animator:rotateZ( 108, 143, ptAngle * -0.3, 0.37, 0.6, 0.1)
	animator:rotateX( 72, 107, ptAngle * -0.4, 0.4, 0.6, 0.1)
	animator:rotateX( 108, 143, ptAngle * -0.4, 0.37, 0.6, 0.1)
	
elseif I:isOf(data.item, Items:get("minecraft:iron_boots")) then
    animator:rotateZ( 0, 17, ywAngle * 0.4, 0.4, 0.6, 0.1)
	animator:rotateZ( 18, 35, ywAngle * 0.4, 0.37, 0.6, 0.1)
	animator:rotateZ( 0, 17, ptAngle * 0.3, 0.4, 0.6, 0.1)
	animator:rotateZ( 18, 35, ptAngle * -0.3, 0.37, 0.6, 0.1)
	animator:rotateX( 0, 17, ptAngle * -0.4, 0.4, 0.6, 0.1)
	animator:rotateX( 18, 35, ptAngle * -0.4, 0.37, 0.6, 0.1)
	--outline
	animator:rotateZ( 35, 53, ywAngle * 0.4, 0.4, 0.6, 0.1)
	animator:rotateZ( 54, 72, ywAngle * 0.4, 0.37, 0.6, 0.1)
	animator:rotateZ( 35, 53, ptAngle * 0.3, 0.4, 0.6, 0.1)
	animator:rotateZ( 54, 72, ptAngle * -0.3, 0.37, 0.6, 0.1)
	animator:rotateX( 35, 53, ptAngle * -0.4, 0.4, 0.6, 0.1)
	animator:rotateX( 54, 72, ptAngle * -0.4, 0.37, 0.6, 0.1)	
	
elseif I:isOf(data.item, Items:get("minecraft:golden_boots")) then
    animator:rotateZ( 0, 35, ywAngle * 0.4, 0.4, 0.6, 0.1)
	animator:rotateZ( 36, 71, ywAngle * 0.4, 0.37, 0.6, 0.1)
	animator:rotateZ( 0, 35, ptAngle * 0.3, 0.4, 0.6, 0.1)
	animator:rotateZ( 36, 71, ptAngle * -0.3, 0.37, 0.6, 0.1)
	animator:rotateX( 0, 35, ptAngle * -0.4, 0.4, 0.6, 0.1)
	animator:rotateX( 36, 71, ptAngle * -0.4, 0.37, 0.6, 0.1)
	--outline
	animator:rotateZ( 108, 143, ywAngle * 0.4, 0.4, 0.6, 0.1)
	animator:rotateZ( 72, 107, ywAngle * 0.4, 0.37, 0.6, 0.1)
	animator:rotateZ( 108, 143, ptAngle * 0.3, 0.4, 0.6, 0.1)
	animator:rotateZ( 72, 107, ptAngle * -0.3, 0.37, 0.6, 0.1)
	animator:rotateX( 108, 143, ptAngle * -0.4, 0.4, 0.6, 0.1)
	animator:rotateX( 72, 107, ptAngle * -0.4, 0.37, 0.6, 0.1)
	
elseif I:isOf(data.item, Items:get("minecraft:chainmail_boots")) then
	animator:rotateZ( 0, 23, ywAngle * 0.4, 0.4, 0.6, 0.1)
	animator:rotateZ( 24, 47, ywAngle * 0.4, 0.37, 0.6, 0.1)
	animator:rotateZ( 0, 23, ptAngle * 0.3, 0.4, 0.6, 0.1)
	animator:rotateZ( 24, 47, ptAngle * -0.3, 0.37, 0.6, 0.1)
	animator:rotateX( 0, 23, ptAngle * -0.4, 0.4, 0.6, 0.1)
	animator:rotateX( 24, 47, ptAngle * -0.4, 0.37, 0.6, 0.1)
	--outline
	animator:rotateZ( 48, 71, ywAngle * 0.4, 0.4, 0.6, 0.1)
	animator:rotateZ( 72, 95, ywAngle * 0.4, 0.37, 0.6, 0.1)
	animator:rotateZ( 48, 71, ptAngle * 0.3, 0.4, 0.6, 0.1)
	animator:rotateZ( 72, 95, ptAngle * -0.3, 0.37, 0.6, 0.1)
	animator:rotateX( 48, 71, ptAngle * -0.4, 0.4, 0.6, 0.1)
	animator:rotateX( 72, 95, ptAngle * -0.4, 0.37, 0.6, 0.1)
	
elseif I:isOf(data.item, Items:get("minecraft:netherite_boots")) then
	animator:rotateZ( 0, 29, ywAngle * 0.4, 0.4, 0.6, 0.1)
	animator:rotateZ( 30, 59, ywAngle * 0.4, 0.37, 0.6, 0.1)
	animator:rotateZ( 0, 29, ptAngle * 0.3, 0.4, 0.6, 0.1)
	animator:rotateZ( 30, 59, ptAngle * -0.3, 0.37, 0.6, 0.1)
	animator:rotateX( 0, 29, ptAngle * -0.4, 0.4, 0.6, 0.1)
	animator:rotateX( 30, 59, ptAngle * -0.4, 0.37, 0.6, 0.1)
	--outline
	animator:rotateZ( 60, 89, ywAngle * 0.4, 0.4, 0.6, 0.1)
	animator:rotateZ( 90, 119, ywAngle * 0.4, 0.37, 0.6, 0.1)
	animator:rotateZ( 60, 89, ptAngle * 0.3, 0.4, 0.6, 0.1)
	animator:rotateZ( 90, 119, ptAngle * -0.3, 0.37, 0.6, 0.1)
	animator:rotateX( 60, 89, ptAngle * -0.4, 0.4, 0.6, 0.1)
	animator:rotateX( 90, 119, ptAngle * -0.4, 0.37, 0.6, 0.1)
	
elseif I:isOf(data.item, Items:get("minecraft:turtle_helmet")) then
    animator:rotateZ( 44, 47, ptAngle * 0.7, 0.4, 0.4, 0.0)
	animator:rotateZ( 48, 51, ptAngle * -0.7, 0.2, 0.4, 0.0)
	animator:rotateZ( 44, 47, ywAngle * 0.4, 0.4, 0.4, 0.0)
	animator:rotateZ( 48, 51, ywAngle * 0.4, 0.2, 0.4, 0.0)
	animator:rotateX( 44, 47, ptAngle * -0.3, 0.5, 0.4, 0.0)
	animator:rotateX( 48, 51, ptAngle * -0.3, 0.2, 0.4, 0.0)
	--bottom
	animator:rotateZ( 46, 47, ptAngle * 0.5, 0.62, 0.12, 0.0)
	animator:rotateZ( 50, 51, ptAngle * -0.5, 0.15, 0.12, 0.0)
	animator:rotateZ( 46, 47, ywAngle * 0.4, 0.62, 0.12, 0.0)
	animator:rotateZ( 50, 51, ywAngle * 0.4, 0.15, 0.12, 0.0)
	animator:rotateX( 46, 47, ptAngle * -0.3, 0.62, 0.12, 0.0)
	animator:rotateX( 50, 51, ptAngle * -0.3, 0.15, 0.12, 0.0)

elseif I:isOf(data.item, Items:get("minecraft:wolf_armor")) then
    animator:rotateX( 12, 13, ptAngle * -0.7, 0.4, 0.4, 0.0)
	animator:rotateX( 14, 15, ptAngle * 0.7, 0.4, 0.4, 0.0)
	animator:rotateZ( 12, 13, ywAngle * 0.5, 0.4, 0.4, 0.0)
	animator:rotateZ( 14, 15, ywAngle * 0.5, 0.4, 0.4, 0.0)
	--head
    animator:rotateZ( 0, 15, ptAngle * 0.4, 0.0, 0.5, -0.2)
	animator:rotateZ( 0, 15, ywAngle * 0.4, 0.0, 0.5, -0.2)
	
	animator:rotateZ( 34, 51, ptAngle * -0.4, -0.1, 0.5, -0.2)
	animator:rotateZ( 34, 51, ywAngle * -0.4, -0.1, 0.5, -0.2)
	
	animator:moveY(0, 51, M:clamp(0.09 * fall, 0, 150))
	
elseif I:isOf(data.item, Items:get("minecraft:elytra")) then
	animator:rotateZ( 0, 9, ywAngle * 0.55, 0.4, 1.5, 0.1)
	animator:rotateZ( 10, 19, ywAngle * 0.45, 0.37, 1.5, 0.1)
	animator:rotateZ( 0, 9, ptAngle * 0.3, 0.4, 1.5, 0.1)
	animator:rotateZ( 10, 19, ptAngle * -0.3, 0.37, 1.5, 0.1)
	animator:rotateX( 0, 9, ptAngle * -0.4, 0.4, 1.5, 0.1)
	animator:rotateX( 10, 19, ptAngle * -0.4, 0.37, 1.5, 0.1) 
	--outline
	animator:rotateZ( 62, 103, ywAngle * 0.55, 0.4, 1.5, 0.1)
	animator:rotateZ( 20, 61, ywAngle * 0.45, 0.37, 1.5, 0.1)
	animator:rotateZ( 62, 103, ptAngle * 0.3, 0.4, 1.5, 0.1)
	animator:rotateZ( 20, 61, ptAngle * -0.3, 0.37, 1.5, 0.1)
	animator:rotateX( 62, 103, ptAngle * -0.4, 0.4, 1.5, 0.1)
	animator:rotateX( 20, 61, ptAngle * -0.4, 0.37, 1.5, 0.1)

elseif I:isOf(data.item, Items:get("minecraft:golden_helmet")) then
	animator:rotateZ( 90, 91, ywAngle * -0.65, 0.4, 0.5, 0.1)
	animator:rotateX( 90, 91, ptAngle * -0.55, 0.4, 0.5, 0.1)
	--outline
	animator:rotateZ( 182, 187, ywAngle * -0.65, 0.4, 0.5, 0.1)
	animator:rotateX( 182, 187, ptAngle * -0.55, 0.4, 0.5, 0.1)
	
elseif I:isOf(data.item, Items:get("minecraft:leather_helmet")) then
	animator:rotateZ( 86, 87, ywAngle * 0.45, 0.1, 0.15, 0.1)
	animator:rotateZ( 88, 89, ywAngle * 0.45, 0.4, 0.15, 0.1)
	animator:rotateZ( 86, 87, ptAngle * -0.45, 0.1, 0.15, 0.1)
	animator:rotateZ( 88, 89, ptAngle * 0.45, 0.4, 0.15, 0.1)
	animator:rotateX( 86, 87, ptAngle * 0.45, 0.1, 0.15, 0.1)
	animator:rotateX( 88, 89, ptAngle * 0.45, 0.4, 0.15, 0.1)
	--top
	animator:rotateZ( 90, 91, ywAngle * -0.5, 0.1, 0.3, 0.1)
	animator:rotateZ( 92, 93, ywAngle * -0.5, 0.25, 0.3, 0.1)
	animator:rotateZ( 90, 91, ptAngle * -0.5, 0.1, 0.25, 0.1)
	animator:rotateZ( 92, 93, ptAngle * 0.5, 0.25, 0.25, 0.1)
	animator:rotateX( 90, 91, ptAngle * 0.5, 0.1, 0.3, 0.1)
	animator:rotateX( 92, 93, ptAngle * 0.5, 0.25, 0.3, 0.1)
end 

